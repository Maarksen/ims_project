#include <iostream>

#include "TractorFacility.hpp"

using namespace std;
TractorFacility::TractorFacility() {

}


    